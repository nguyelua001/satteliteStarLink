﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarlinkQuiz
{
    public class Coordinate
    {
        public Int32 ID { get; set; }
        public double x { get; set; }
        public double y { get; set; }
        public double z { get; set; }

        public Coordinate()
        {

        }
        public Coordinate(Int32 _id, double _x, double _y, double _z)
        {
            ID = _id;
            x = _x;
            y = _y;
            z = _z;
        }

        public Coordinate(double _x, double _y, double _z)
        {
            x = _x;
            y = _y;
            z = _z;
        }

    }

    public class Angle
    {
        public double x { get; set; }
        public double y { get; set; }
        public double z { get; set; }
    }
}
