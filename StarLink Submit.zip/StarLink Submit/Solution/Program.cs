using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime;
using System.Xml;

namespace StarlinkQuiz
{
    class Program
    {
        //Declare three mail lists
        static List<Coordinate> StarLinkList = new List<Coordinate>();
        static List<Coordinate> UserList = new List<Coordinate>();
        static List<Coordinate> interfererList = new List<Coordinate>();

        static readonly Coordinate origin = new Coordinate(0, 0, 0); // center of the earth.
        private const double Max_non_satellite_Interference = 20.00;
        private const double Min_between_Beams = 10.00;
        private const double max_user_visible_angle = 45.00;
        static void Main(string[] args)
        {


            //STEP 1:   Read the sample file and fill the 3 main lists
            Console.WriteLine("Enter the FULL path for the text file: ");
            var fileN = Console.ReadLine();
            if (string.IsNullOrEmpty(fileN)) fileN = @"05_equatorial_plane.txt";
            ReadFile(fileN);

            //STEP 2:   Sort each List with x coordinate
            StarLinkList = StarLinkList.OrderBy(x => x.x).ToList();
            UserList = UserList.OrderBy(x => x.x).ToList();
            interfererList = interfererList.OrderBy(x => x.x).ToList();

            //STEP 3: Run the following logic:

            //1.    Check the constraint #3 first
            //      Traverse through each sat with the user list
            //      Group all users which meet the constraint #3:  Users are within 45 degrees
            //      with the sat location
            //      Note:  each user might belong to more than 1 satellite 
            //2.    Check on the constraint #1 next: 
            //      In each satellite, now check on each users against each for more than 20 degrees
            //      difference.  
            //3.    Now check the constraint #2 
            //
            //      After each user passes all threes constraints, permanently mark it with satellite 
            //      And remove it from any other groups.   
            //      Make sure after checking three constraints, only 32 beams (or users) max in each sat

            //Support functions:   


            //Testing the list to amke sure all rows are captured properly
            Console.WriteLine($"Total number of items in StarLink list is:  {StarLinkList.Count}");
            Console.WriteLine($"Total number of items in user list is:  {UserList.Count}");
            Console.WriteLine($"Total number of items in interferer list is:  {interfererList.Count}");

            #region Get the groups of users that meet requirement#3 for each sat 

            var usersBelongToSat = new Dictionary<Coordinate, List<Coordinate>>();     //First is the sat loc, the second is the list of users loc meet Constraint #3

            for (var i = 0; i < StarLinkList.Count - 1; i++)
            {
                List<Coordinate> list = new List<Coordinate>();
                foreach (var user in UserList)
                {
                    if (check_sat_user(user, StarLinkList[i]))
                    {
                        list.Add(user);
                    }
                                           
                }   
                usersBelongToSat.Add(StarLinkList[i], list); 
            }
            #endregion

            #region Scan through the list of users in EACH sat to see if they meet the constraint #1

            foreach (var sat in usersBelongToSat)
            {
                List<Coordinate> UserLocList = sat.Value;
                int i, j = 0;
                int BeamCount = 0;
                int MaxBeamPerSat = 32;

                List<Coordinate> holder = new List<Coordinate>();

                holder.Add(UserLocList[0]); //The first user_loc is always the valid one so add it to the list regardless
                BeamCount++;

                for (i = 0; i < UserLocList.Count; i++)
                {

                    for (j = i + 1; j < UserLocList.Count; j++)
                    {
                        var CheckIfTwoUsersAreInGoodDistance = check_users(sat.Key, UserLocList[i], UserList[j]);
                    
                        //If CheckIfTwoUsersAreInGoodDistance = true =>  Two user_locs do not fall into constraint #1
                        if (!CheckIfTwoUsersAreInGoodDistance) continue;

                        holder.Add(UserLocList[j]);
                        BeamCount++;
                    }
                }

            }
            

            #endregion
        }

        private static void ReadFile(string filename)
        {
            try
            {
                using (var sr = File.OpenText(filename))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        //Now split the line and insert into the main lists
                        read_object(line);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }

        }

        private static void read_object(string line)
        {
            if (line.StartsWith("#")) return;
            if(string.IsNullOrEmpty(line)) return;
            var item = new Coordinate();
            var parts = line.Split(' ');
            item.ID = Convert.ToInt32(parts[1]);
            item.x = Convert.ToDouble(parts[2]);
            item.y = Convert.ToDouble(parts[3]);
            item.z = Convert.ToDouble(parts[4]);

            switch (parts[0])
            {
                case "sat":
                    StarLinkList.Add(item);
                    break;
                case "user":
                    UserList.Add(item);
                    break;
                case "interferer":
                    interfererList.Add(item);
                    break;
            }

        }

        //Calcute the degree from three points
        private static double CalculateAngle(Coordinate vertex, Coordinate pointA, Coordinate pointB)
        {
            var va = new Coordinate(pointA.x - vertex.x, pointA.y - vertex.y, pointA.z - vertex.z);
            var vb = new Coordinate(pointB.x - vertex.x, pointB.y - vertex.y, pointB.z - vertex.z);

            //calculate vector's magnitude
            var va_mag = Math.Sqrt(Math.Pow(va.x, 2) + Math.Pow(va.y, 2) + Math.Pow(va.z, 2));
            var vb_mag = Math.Sqrt(Math.Pow(vb.x, 2) + Math.Pow(vb.y, 2) + Math.Pow(vb.z, 2));

            //Normalize each vector
            var va_norm = new Coordinate(va.x / va_mag, va.y / va_mag, va.z / va_mag);
            var vb_norm = new Coordinate(vb.x / vb_mag, vb.y / vb_mag, vb.z / vb_mag);

            //Calculate the dot product
            var dot_product = va_norm.x * vb_norm.x + va_norm.y * vb_norm.y + va_norm.z * vb_norm.z;


            var dot_product_bound = Math.Min(1.0, Math.Max(-1.0, dot_product));
            if (Math.Abs(dot_product_bound - dot_product) > 1E-06)
            {
                Console.WriteLine($"dot_product: {dot_product} bounded to {dot_product_bound}");
            }

            var radian = Math.Acos(dot_product_bound);
            

            var degrees = (180 / Math.PI) * radian;

            //Test on the values: 
            //Console.WriteLine($"Radian: {radian}  |  degree:  {degrees}");

            // Return the angle.
            return degrees;
        }

        //Check on the constraint #3
        private static bool check_sat_user(Coordinate user_pos, Coordinate sat_pos)
        {
            var angle = CalculateAngle(user_pos, origin, sat_pos);
            // User terminals are unable to form beams too far off of from vertical.
            return !(angle <= 180.0 - max_user_visible_angle);
        }

        //Check on the constraint #2
        private static bool check_sat_user_nonSat(Coordinate sat_loc, Coordinate user_loc) {
            // Iterate over the non-Starlink satellites.

            foreach (var item in interfererList)
            {
                var angle = CalculateAngle(user_loc, sat_loc, item);
                if (angle < Max_non_satellite_Interference)
                    return true;
            }
            return false;
        }

        //Check on the constraint #1
        //Return TRUE if two user_loc meet the requirement ( >= 10 degrees)
        //Return FALSE if they are TOO close
        private static bool check_users(Coordinate sat_loc, Coordinate userA_loc, Coordinate userB_loc)
        {
            var angle = CalculateAngle(sat_loc, userA_loc, userB_loc);

            return angle >= Min_between_Beams;
        }
    }
}
